#include <stdio.h>
void main( ) {
    float a = 12.25, b = 12.52 ;
    
    if (a = b)
        printf("\na and b are equal" ) ;
    else
        printf ( "\na and b are not equal" ) ;
}
