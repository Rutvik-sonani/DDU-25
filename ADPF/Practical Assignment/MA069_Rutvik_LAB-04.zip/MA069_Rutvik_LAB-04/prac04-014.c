#include <stdio.h>
int main()
{
    int (x)=10;
    printf("x= %d",x);
    
    return 0;
}
