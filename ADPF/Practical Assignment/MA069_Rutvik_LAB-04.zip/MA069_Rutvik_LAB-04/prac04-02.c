#include <stdio.h>
void main( ) {
    if('X' < 'x' )
        printf ( "\nascii value of X is smaller than that of x" ) ;
}
