#include <stdio.h>
void main( ) {
    int ji = 65 ;
    printf ( "\nji >= 65 ? %d : %c", ji);
}
