#include <stdio.h>
void main( ) {
    int x = 10 , y = 20;
    
    if ( x >= 2 and y <=50 )
        printf ( "\n%d", x ) ;
}
