#include <stdio.h>
void main( ) {
    int a, b ;
    scanf ( "%d %d",a, b ) ;
    
    if ( a > b ) ;
        printf ( "a is large" ) ;
    else
        printf ( "b is large" ) ;
}