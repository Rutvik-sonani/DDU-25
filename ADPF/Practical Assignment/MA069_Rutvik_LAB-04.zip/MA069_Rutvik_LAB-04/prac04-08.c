#include <stdio.h>
void main( )
{
    int i = 2, j = 5 ;
    
    if ( i == 2 && j == 5 )
        printf ( "\nSolved at last" ) ;
}