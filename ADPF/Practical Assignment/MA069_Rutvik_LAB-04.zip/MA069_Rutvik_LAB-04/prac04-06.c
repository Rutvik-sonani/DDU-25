#include <stdio.h>
void main(){
    int x = 10 ;
    
    if x >= 2
        printf ( "\n%d", x ) ;
}