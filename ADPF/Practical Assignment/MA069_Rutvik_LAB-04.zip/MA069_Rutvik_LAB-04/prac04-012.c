#include <stdio.h>
void main( ) {
    int i = 10, j ;
    
    i >= 5 ? ( j = 10 ) : ( j = 15 ) ;
    
    printf ( "\n%d %d", i, j ) ;
}
