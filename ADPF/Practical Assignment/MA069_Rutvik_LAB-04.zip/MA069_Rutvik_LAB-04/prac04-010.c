#include <stdio.h>
void main( ) {
    int i = 10, j = 10 ;
    
    if ( i && j == 10)
        printf ( "\nHave a nice day!!!" ) ;
}
