#include <stdio.h>
int main( ) {
    int x = 30 , y = 40 ;
    if ( x == y )
        printf( "x is equal to y" ) ;
    elseif ( x > y )
        printf( "x is greater than y" ) ;
    elseif ( x < y )
        printf( "x is less than y" ) ;
}
