#include <stdio.h>
#define print "%sprintwonders "
int main()
{
    int a=1,b=2,c=3;
    printf(print,print);
    return 0;
}