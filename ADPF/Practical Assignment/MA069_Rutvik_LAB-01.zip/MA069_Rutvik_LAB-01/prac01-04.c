#include<stdio.h>

void main(){
    int a,b;

    printf("Enter a no : ");
    scanf("%d",&a);

    printf("Enter b no : ");
    scanf("%d",&b);

    int mul = a * b;

    printf("Multiplication is : %d",mul);
}