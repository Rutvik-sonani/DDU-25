#include<stdio.h>

void main(){
    int a,b;

    printf("Enter a no : ");
    scanf("%d",&a);

    printf("Enter b no : ");
    scanf("%d",&b);

    int sum = a + b;

    printf("Sum is : %d",sum);
}