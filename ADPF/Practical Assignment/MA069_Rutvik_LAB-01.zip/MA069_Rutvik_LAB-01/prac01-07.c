#include<stdio.h>

void main(){
    printf("Name : Rutvik Sonani\n");
    printf("Uni : DDU\n");
    printf("Department : MCA\n");
    printf("Roll no : MA069\n");
}