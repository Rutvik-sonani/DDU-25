#include <stdio.h>
void main(){
    int x = 15;
    printf ("\n%d %d %d", x != 15, x=20, x < 30) ;
}