#include <stdio.h>
void main( ) {
    int i = 4, z = 12;
    
    if ( i = 5 || z > 50 )
        printf ( "\n Hello!!!" ) ;
    else
        printf ( "\nBye !!!" ) ;
}