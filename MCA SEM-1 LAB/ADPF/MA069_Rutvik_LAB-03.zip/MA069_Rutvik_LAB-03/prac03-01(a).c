#include <stdio.h>
void main() {
    int i = 65 ;
    char j = 'A';
    
    if(i == j)
        printf("Hello!!") ;
    else
        printf("Welcome!!!");
}
