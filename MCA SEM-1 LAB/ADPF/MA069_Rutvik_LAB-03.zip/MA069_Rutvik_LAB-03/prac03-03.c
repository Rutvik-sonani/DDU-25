#include<stdio.h>
#include<conio.h>

int main(){
    char ch;

    printf("Enter any char : ");
    scanf("%c",&ch);

    printf("ASCII Value is : %d",ch);

    return 0;
}