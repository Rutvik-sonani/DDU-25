#include <stdio.h>
void main() {
    int i = -3, j = 3 ;
    
    if ( !i + !j * 1 )
        printf ( "\nHello!!!" ) ;
    else
        printf ( "\nWelcome!!!" ) ;
}