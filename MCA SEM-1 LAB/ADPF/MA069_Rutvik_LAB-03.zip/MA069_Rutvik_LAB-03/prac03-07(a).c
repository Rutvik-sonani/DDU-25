#include <stdio.h>
void main( ) {
    int i = -1, j = 1, k ,l ;
    k = i && j ;
    l = i || j ;
    // printf ( "%d %d", I, j ) ;
    printf ( "%d %d", i, j ) ;
}
