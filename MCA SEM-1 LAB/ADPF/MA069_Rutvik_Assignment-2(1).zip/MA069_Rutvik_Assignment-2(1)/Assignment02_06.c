#include<stdio.h>

int main()
{
    int n;
    
    printf("Enter the number: ");
    scanf("%d",&n);

    for(int i=n;i>=1;i--)
    {
        for(int j=1;j<=i;j++)
        {
            printf("%d%c",j,64+j);
        }
        printf("\n");
    }
    return 0;
}